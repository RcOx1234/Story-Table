import { useState } from 'react';
import { useStore } from '@/store';
import { motion } from 'framer-motion';
import { Plus, Clock, ChevronRight } from 'lucide-react';
interface Props { worldId: string; }

export function TimelinesSection({ worldId }: Props) {
  const timelines = useStore((s) => s.getTimelinesByWorld(worldId));
  const addTimeline = useStore((s) => s.addTimeline);
  const scenes = useStore((s) => s.scenes.filter((sc) => sc.worldId === worldId && !sc.isDeleted));
  const [activeTimeline, setActiveTimeline] = useState<string>('');

  const activeId = activeTimeline || timelines[0]?.id;
  const active = timelines.find((t) => t.id === activeId);
  const timelineScenes = scenes.filter((s) => s.timelineId === activeId);

  const handleAdd = () => {
    const name = prompt('Nombre de la línea temporal:');
    if (!name) return;
    addTimeline({ worldId, name, description: '', order: timelines.length + 1, startDate: '', endDate: '', color: `#${Math.floor(Math.random()*16777215).toString(16)}` });
  };

  if (timelines.length === 0) {
    return (
      <div className="text-center py-16">
        <Clock size={48} className="text-[#2A3045] mx-auto mb-4" />
        <p className="text-[#5A6078] mb-4">No hay líneas temporales</p>
        <button onClick={handleAdd} className="story-btn-primary text-sm"><Plus size={16} /> Crear Timeline</button>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div className="flex gap-2">
          {timelines.map((tl) => (
            <button
              key={tl.id}
              onClick={() => setActiveTimeline(tl.id)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                activeId === tl.id 
                  ? 'text-white' 
                  : 'text-[#8B91A7] hover:text-[#E8E9EB] bg-[#1E2230]'
              }`}
              style={activeId === tl.id ? { backgroundColor: tl.color } : {}}
            >
              {tl.name}
            </button>
          ))}
        </div>
        <button onClick={handleAdd} className="story-btn-secondary text-sm"><Plus size={16} /> Nueva Línea</button>
      </div>

      {active && (
        <div className="mb-6">
          <h3 className="text-lg font-semibold text-[#E8E9EB] mb-1">{active.name}</h3>
          {active.description && <p className="text-sm text-[#8B91A7]">{active.description}</p>}
        </div>
      )}

      {/* Timeline visualization */}
      <div className="relative">
        <div className="absolute left-6 top-0 bottom-0 w-0.5" style={{ backgroundColor: active?.color || '#3A4460' }} />
        
        <div className="space-y-4">
          {timelineScenes.map((scene, i) => (
            <motion.div
              key={scene.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1 }}
              className="flex items-start gap-4 ml-0"
            >
              <div 
                className="w-3 h-3 rounded-full mt-2 flex-shrink-0 border-2 border-[#0B0D10]"
                style={{ backgroundColor: active?.color }}
              />
              <div className="story-card p-4 flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h4 className="font-medium text-[#E8E9EB]">{scene.title}</h4>
                  <ChevronRight size={14} className="text-[#5A6078]" />
                </div>
                {scene.description && <p className="text-xs text-[#8B91A7] line-clamp-2">{scene.description}</p>}
              </div>
            </motion.div>
          ))}
          
          {timelineScenes.length === 0 && (
            <div className="ml-10 text-sm text-[#5A6078]">No hay escenas en esta línea temporal</div>
          )}
        </div>
      </div>
    </div>
  );
}
