import { useState } from 'react';
import { useStore } from '@/store';
import { motion } from 'framer-motion';
import { Plus, Search, Heart, Route, Zap } from 'lucide-react';
interface Props { worldId: string; }

export function PlotsSection({ worldId }: Props) {
  const plots = useStore((s) => s.getPlotsByWorld(worldId));
  const addPlot = useStore((s) => s.addPlot);
  const toggleFav = useStore((s) => s.toggleFavoritePlot);
  const [search, setSearch] = useState('');

  const filtered = plots.filter((p) => !search || p.title.toLowerCase().includes(search.toLowerCase()));

  const handleAdd = () => {
    const title = prompt('Título de la trama:');
    if (!title) return;
    addPlot({ worldId, title, synopsis: '', characters: [], relatedPlots: [], twists: [], isFavorite: false, isDeleted: false, tags: [] });
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="flex-1 relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#5A6078]" />
          <input type="text" placeholder="Buscar tramas..." value={search} onChange={(e) => setSearch(e.target.value)} className="story-input w-full pl-10" />
        </div>
        <button onClick={handleAdd} className="story-btn-primary text-sm"><Plus size={16} /> Agregar</button>
      </div>
      {filtered.length === 0 ? (
        <div className="text-center py-16">
          <Route size={48} className="text-[#2A3045] mx-auto mb-4" />
          <p className="text-[#5A6078] mb-4">No hay tramas</p>
          <button onClick={handleAdd} className="story-btn-primary text-sm"><Plus size={16} /> Crear Trama</button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {filtered.map((plot, i) => (
            <motion.div key={plot.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }} className="story-card p-5 group relative">
              <button onClick={() => toggleFav(plot.id)} className="absolute top-3 right-3 p-1.5 rounded-lg hover:bg-[#1E2230] transition-all">
                <Heart size={14} className={plot.isFavorite ? 'text-[#D61E2B] fill-[#D61E2B]' : 'text-[#5A6078]'} />
              </button>
              <div className="flex items-center gap-2 mb-2">
                <Route size={14} className="text-[#D61E2B]" />
                <h3 className="font-semibold text-[#E8E9EB]">{plot.title}</h3>
              </div>
              {plot.synopsis && <p className="text-sm text-[#8B91A7] line-clamp-3 mb-3">{plot.synopsis}</p>}
              {plot.twists.length > 0 && (
                <div className="space-y-1 mt-3">
                  <p className="text-xs text-[#5A6078] font-mono uppercase">Giros:</p>
                  {plot.twists.map((twist, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-xs text-[#8B91A7]">
                      <Zap size={10} className="text-[#EAB308] flex-shrink-0" />
                      <span className="line-clamp-1">{twist}</span>
                    </div>
                  ))}
                </div>
              )}
              <div className="mt-3 pt-3 border-t border-[#1E2230] text-xs text-[#5A6078]">
                {plot.characters.length} personajes involucrados
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
