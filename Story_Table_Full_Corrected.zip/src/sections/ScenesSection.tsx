import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '@/store';
import { motion } from 'framer-motion';
import { Plus, Search, Heart, Flame, Users, MapPin } from 'lucide-react';
import type { Scene } from '@/types';

const statusLabels: Record<string, { label: string; color: string }> = {
  pending: { label: 'Pendiente', color: '#EAB308' },
  confirmed: { label: 'Confirmado', color: '#22C55E' },
  revision: { label: 'En Revisión', color: '#3B82F6' },
  discarded: { label: 'Descartado', color: '#6B7280' },
  important: { label: 'Importante', color: '#D61E2B' },
  secret: { label: 'Secreto', color: '#8B5CF6' },
  canon: { label: 'Canon', color: '#22C55E' },
  noncanon: { label: 'No Canon', color: '#6B7280' },
};

interface Props {
  worldId: string;
}

export function ScenesSection({ worldId }: Props) {
  const navigate = useNavigate();
  const scenes = useStore((s) => s.getScenesByWorld(worldId));
  const addScene = useStore((s) => s.addScene);
  const toggleFavorite = useStore((s) => s.toggleFavoriteScene);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  const filtered = scenes.filter((s) => {
    const matchSearch = !search || s.title.toLowerCase().includes(search.toLowerCase());
    const matchStatus = !statusFilter || s.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const handleAdd = () => {
    const title = prompt('Título de la escena:');
    if (!title) return;
    const newScene: Omit<Scene, 'id' | 'createdAt' | 'updatedAt'> = {
      worldId,
      title,
      description: '',
      content: '',
      characters: [],
      placeId: '',
      placeName: '',
      timelineId: '',
      timelineName: '',
      emotionalIntensity: 1,
      music: '',
      dialogues: [],
      reveals: [],
      images: [],
      video: '',
      audio: '',
      status: 'pending',
      isFavorite: false,
      isDeleted: false,
      tags: [],
    };
    addScene(newScene);
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="flex-1 relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#5A6078]" />
          <input
            type="text"
            placeholder="Buscar escenas..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="story-input w-full pl-10"
          />
        </div>
        <div className="flex gap-2">
          <select 
            value={statusFilter} 
            onChange={(e) => setStatusFilter(e.target.value)}
            className="story-input text-sm"
          >
            <option value="">Todos los estados</option>
            {Object.entries(statusLabels).map(([key, { label }]) => (
              <option key={key} value={key}>{label}</option>
            ))}
          </select>
          <button onClick={handleAdd} className="story-btn-primary text-sm">
            <Plus size={16} /> Agregar
          </button>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-16">
          <p className="text-[#5A6078] mb-4">No hay escenas aún</p>
          <button onClick={handleAdd} className="story-btn-primary text-sm">
            <Plus size={16} /> Crear Escena
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((scene, i) => (
            <motion.div
              key={scene.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              onClick={() => navigate(`/world/${worldId}/scene/${scene.id}`)}
              className="story-card p-5 cursor-pointer hover:bg-[#1A1E28] transition-all group"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="font-semibold text-[#E8E9EB]">{scene.title}</h3>
                    <span 
                      className="text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full font-medium flex-shrink-0"
                      style={{ 
                        backgroundColor: `${statusLabels[scene.status]?.color}15`, 
                        color: statusLabels[scene.status]?.color 
                      }}
                    >
                      {statusLabels[scene.status]?.label}
                    </span>
                  </div>
                  
                  {scene.description && (
                    <p className="text-sm text-[#8B91A7] line-clamp-2 mb-3">{scene.description}</p>
                  )}

                  <div className="flex items-center gap-4 text-xs text-[#5A6078]">
                    {scene.placeName && (
                      <span className="flex items-center gap-1">
                        <MapPin size={12} /> {scene.placeName}
                      </span>
                    )}
                    {scene.timelineName && (
                      <span className="flex items-center gap-1">
                        <Users size={12} /> {scene.characters.length} personajes
                      </span>
                    )}
                    <span className="flex items-center gap-1">
                      <Flame size={12} className={scene.emotionalIntensity >= 4 ? 'text-[#D61E2B]' : ''} />
                      Intensidad: {scene.emotionalIntensity}/5
                    </span>
                  </div>
                </div>

                <button
                  onClick={(e) => { e.stopPropagation(); toggleFavorite(scene.id); }}
                  className="p-2 rounded-lg hover:bg-[#1E2230] transition-all flex-shrink-0 ml-4"
                >
                  <Heart size={16} className={scene.isFavorite ? 'text-[#D61E2B] fill-[#D61E2B]' : 'text-[#5A6078]'} />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
