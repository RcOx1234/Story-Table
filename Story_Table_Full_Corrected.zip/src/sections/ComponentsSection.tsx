import { useState } from 'react';
import { useStore } from '@/store';
import { motion } from 'framer-motion';
import { Plus, Search, Heart, Box, Gem } from 'lucide-react';
const typeLabels: Record<string, string> = { object: 'Objeto', letter: 'Carta', relic: 'Reliquia', weapon: 'Arma', artifact: 'Artefacto', other: 'Otro' };

interface Props { worldId: string; }

export function ComponentsSection({ worldId }: Props) {
  const components = useStore((s) => s.getComponentsByWorld(worldId));
  const addComp = useStore((s) => s.addComponent);
  const toggleFav = useStore((s) => s.toggleFavoriteComponent);
  const [search, setSearch] = useState('');

  const filtered = components.filter((c) => !search || c.name.toLowerCase().includes(search.toLowerCase()));

  const handleAdd = () => {
    const name = prompt('Nombre del componente:');
    if (!name) return;
    addComp({ worldId, name, description: '', history: '', target: '', scenes: [], type: 'object', isFavorite: false, isDeleted: false, tags: [] });
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="flex-1 relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#5A6078]" />
          <input type="text" placeholder="Buscar componentes..." value={search} onChange={(e) => setSearch(e.target.value)} className="story-input w-full pl-10" />
        </div>
        <button onClick={handleAdd} className="story-btn-primary text-sm"><Plus size={16} /> Agregar</button>
      </div>
      {filtered.length === 0 ? (
        <div className="text-center py-16">
          <Gem size={48} className="text-[#2A3045] mx-auto mb-4" />
          <p className="text-[#5A6078] mb-4">No hay componentes</p>
          <button onClick={handleAdd} className="story-btn-primary text-sm"><Plus size={16} /> Crear</button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((comp, i) => (
            <motion.div key={comp.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }} className="story-card p-5 group relative">
              <button onClick={() => toggleFav(comp.id)} className="absolute top-3 right-3 p-1.5 rounded-lg hover:bg-[#1E2230] transition-all">
                <Heart size={14} className={comp.isFavorite ? 'text-[#D61E2B] fill-[#D61E2B]' : 'text-[#5A6078]'} />
              </button>
              <div className="flex items-center gap-2 mb-2">
                <Box size={14} className="text-[#8B5CF6]" />
                <span className="text-[10px] uppercase tracking-wider text-[#5A6078] bg-[#1E2230] px-2 py-0.5 rounded-full">{typeLabels[comp.type]}</span>
              </div>
              <h3 className="font-semibold text-[#E8E9EB] mb-1">{comp.name}</h3>
              {comp.description && <p className="text-xs text-[#8B91A7] line-clamp-3">{comp.description}</p>}
              {comp.target && <p className="mt-2 text-xs text-[#5A6078]">Destinatario: {comp.target}</p>}
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
