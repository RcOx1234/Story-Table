import { useState } from 'react';
import { useStore } from '@/store';
import { motion } from 'framer-motion';
import { Plus, Lightbulb, Heart } from 'lucide-react';

interface Props { worldId: string; }

const typeLabels: Record<string, { label: string; color: string }> = {
  scene: { label: 'Escena', color: '#22C55E' },
  character: { label: 'Personaje', color: '#3B82F6' },
  plot: { label: 'Trama', color: '#D61E2B' },
  world: { label: 'Mundo', color: '#8B5CF6' },
  dialogue: { label: 'Diálogo', color: '#EAB308' },
  lore: { label: 'Lore', color: '#EC4899' },
  other: { label: 'Otro', color: '#5A6078' },
};

export function WorldIdeasSection({ worldId }: Props) {
  const ideas = useStore((s) => s.ideas.filter((i) => i.worldId === worldId && !i.isDeleted));
  const addIdea = useStore((s) => s.addIdea);
  const toggleFav = useStore((s) => s.toggleFavoriteIdea);
  const [filter, setFilter] = useState('');

  const filtered = ideas.filter((i) => !filter || i.type === filter);

  const handleAdd = () => {
    const desc = prompt('Describe tu idea:');
    if (!desc) return;
    addIdea({ worldId, description: desc, type: 'scene', references: [], isFavorite: false, isDeleted: false, tags: [] });
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="flex gap-2 flex-wrap">
          <button onClick={() => setFilter('')} className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${!filter ? 'bg-[#D61E2B] text-white' : 'bg-[#1E2230] text-[#8B91A7]'}`}>Todas</button>
          {Object.entries(typeLabels).map(([key, { label }]) => (
            <button key={key} onClick={() => setFilter(key)} className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${filter === key ? 'bg-[#D61E2B] text-white' : 'bg-[#1E2230] text-[#8B91A7]'}`}>{label}</button>
          ))}
        </div>
        <button onClick={handleAdd} className="story-btn-primary text-sm ml-auto"><Plus size={16} /> Nueva Idea</button>
      </div>
      {filtered.length === 0 ? (
        <div className="text-center py-16">
          <Lightbulb size={48} className="text-[#2A3045] mx-auto mb-4" />
          <p className="text-[#5A6078] mb-4">No hay ideas en este mundo</p>
          <button onClick={handleAdd} className="story-btn-primary text-sm"><Plus size={16} /> Capturar Idea</button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-3">
          {filtered.map((idea, i) => (
            <motion.div key={idea.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }} className="story-card p-4 flex items-start gap-4 group relative">
              <button onClick={() => toggleFav(idea.id)} className="p-1.5 rounded-lg hover:bg-[#1E2230] transition-all flex-shrink-0 mt-0.5">
                <Heart size={14} className={idea.isFavorite ? 'text-[#D61E2B] fill-[#D61E2B]' : 'text-[#5A6078]'} />
              </button>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-[#E8E9EB] mb-2">{idea.description}</p>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full font-medium" style={{ backgroundColor: `${typeLabels[idea.type]?.color}15`, color: typeLabels[idea.type]?.color }}>
                    {typeLabels[idea.type]?.label}
                  </span>
                  <span className="text-[10px] text-[#5A6078]">{new Date(idea.createdAt).toLocaleDateString()}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
