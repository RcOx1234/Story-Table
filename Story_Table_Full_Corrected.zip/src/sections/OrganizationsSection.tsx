import { useState } from 'react';
import { useStore } from '@/store';
import { motion } from 'framer-motion';
import { Plus, Search, Heart, Building2, Crown } from 'lucide-react';
const typeLabels: Record<string, string> = { guild: 'Gremio', house: 'Casa', brotherhood: 'Hermandad', company: 'Compañía', clan: 'Clan', other: 'Otro' };

interface Props { worldId: string; }

export function OrganizationsSection({ worldId }: Props) {
  const organizations = useStore((s) => s.getOrganizationsByWorld(worldId));
  const addOrg = useStore((s) => s.addOrganization);
  const toggleFav = useStore((s) => s.toggleFavoriteOrganization);
  const [search, setSearch] = useState('');

  const filtered = organizations.filter((o) => !search || o.name.toLowerCase().includes(search.toLowerCase()));

  const handleAdd = () => {
    const name = prompt('Nombre de la organización:');
    if (!name) return;
    addOrg({ worldId, name, members: [], goals: '', symbols: '', hierarchy: '', type: 'other', isFavorite: false, isDeleted: false, tags: [] });
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="flex-1 relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#5A6078]" />
          <input type="text" placeholder="Buscar organizaciones..." value={search} onChange={(e) => setSearch(e.target.value)} className="story-input w-full pl-10" />
        </div>
        <button onClick={handleAdd} className="story-btn-primary text-sm"><Plus size={16} /> Agregar</button>
      </div>
      {filtered.length === 0 ? (
        <div className="text-center py-16">
          <Building2 size={48} className="text-[#2A3045] mx-auto mb-4" />
          <p className="text-[#5A6078] mb-4">No hay organizaciones</p>
          <button onClick={handleAdd} className="story-btn-primary text-sm"><Plus size={16} /> Crear</button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((org, i) => (
            <motion.div key={org.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }} className="story-card p-5 group relative">
              <button onClick={() => toggleFav(org.id)} className="absolute top-3 right-3 p-1.5 rounded-lg hover:bg-[#1E2230] transition-all">
                <Heart size={14} className={org.isFavorite ? 'text-[#D61E2B] fill-[#D61E2B]' : 'text-[#5A6078]'} />
              </button>
              <div className="flex items-center gap-2 mb-2">
                <Building2 size={14} className="text-[#3B82F6]" />
                <span className="text-[10px] uppercase tracking-wider text-[#5A6078] bg-[#1E2230] px-2 py-0.5 rounded-full">{typeLabels[org.type]}</span>
              </div>
              <h3 className="font-semibold text-[#E8E9EB] mb-2">{org.name}</h3>
              {org.goals && <p className="text-xs text-[#8B91A7] line-clamp-2 mb-2">{org.goals}</p>}
              <div className="mt-2 pt-2 border-t border-[#1E2230] flex items-center justify-between text-xs text-[#5A6078]">
                <span className="flex items-center gap-1"><Crown size={10} /> {org.members.length} miembros</span>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
