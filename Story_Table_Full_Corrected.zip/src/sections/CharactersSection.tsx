import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '@/store';
import { motion } from 'framer-motion';
import { Plus, Search, Heart } from 'lucide-react';
import type { Character } from '@/types';

const roleLabels: Record<string, { label: string; color: string }> = {
  protagonist: { label: 'Protagonista', color: '#22C55E' },
  antagonist: { label: 'Antagonista', color: '#D61E2B' },
  secondary: { label: 'Secundario', color: '#3B82F6' },
  supporting: { label: 'Apoyo', color: '#8B5CF6' },
  extra: { label: 'Extra', color: '#5A6078' },
};

const statusColors: Record<string, string> = {
  alive: '#22C55E',
  dead: '#6B7280',
  missing: '#EAB308',
  unknown: '#5A6078',
};

interface Props {
  worldId: string;
}

export function CharactersSection({ worldId }: Props) {
  const navigate = useNavigate();
  const characters = useStore((s) => s.getCharactersByWorld(worldId));
  const addCharacter = useStore((s) => s.addCharacter);
  const toggleFavorite = useStore((s) => s.toggleFavoriteCharacter);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('');

  const filtered = characters.filter((c) => {
    const matchSearch = !search || c.name.toLowerCase().includes(search.toLowerCase()) || c.alias.toLowerCase().includes(search.toLowerCase());
    const matchRole = !roleFilter || c.role === roleFilter;
    return matchSearch && matchRole;
  });

  const handleAdd = () => {
    const name = prompt('Nombre del personaje:');
    if (!name) return;
    const newChar: Omit<Character, 'id' | 'createdAt' | 'updatedAt'> = {
      worldId,
      name,
      alias: '',
      role: 'secondary',
      house: '',
      age: 0,
      ageByTimeline: {},
      appearance: '',
      personality: '',
      backstory: '',
      goals: '',
      fears: '',
      powers: '',
      relationships: [],
      images: [],
      quotes: [],
      arc: '',
      status: 'alive',
      isFavorite: false,
      isDeleted: false,
      tags: [],
    };
    addCharacter(newChar);
  };

  return (
    <div>
      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="flex-1 relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#5A6078]" />
          <input
            type="text"
            placeholder="Buscar personajes..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="story-input w-full pl-10"
          />
        </div>
        <div className="flex gap-2">
          <select 
            value={roleFilter} 
            onChange={(e) => setRoleFilter(e.target.value)}
            className="story-input text-sm"
          >
            <option value="">Todos los roles</option>
            {Object.entries(roleLabels).map(([key, { label }]) => (
              <option key={key} value={key}>{label}</option>
            ))}
          </select>
          <button onClick={handleAdd} className="story-btn-primary text-sm">
            <Plus size={16} /> Agregar
          </button>
        </div>
      </div>

      {/* Grid */}
      {filtered.length === 0 ? (
        <div className="text-center py-16">
          <p className="text-[#5A6078] mb-4">No hay personajes aún</p>
          <button onClick={handleAdd} className="story-btn-primary text-sm">
            <Plus size={16} /> Crear Personaje
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filtered.map((char, i) => (
            <motion.div
              key={char.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              onClick={() => navigate(`/world/${worldId}/character/${char.id}`)}
              className="story-card p-5 cursor-pointer group relative"
            >
              {/* Favorite */}
              <button
                onClick={(e) => { e.stopPropagation(); toggleFavorite(char.id); }}
                className="absolute top-3 right-3 p-1.5 rounded-lg hover:bg-[#1E2230] transition-all"
              >
                <Heart size={14} className={char.isFavorite ? 'text-[#D61E2B] fill-[#D61E2B]' : 'text-[#5A6078]'} />
              </button>

              {/* Avatar */}
              <div className="w-16 h-16 rounded-full mx-auto mb-3 overflow-hidden bg-[#1E2230]">
                {char.images[0] ? (
                  <img src={char.images[0]} alt={char.name} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-xl font-semibold text-[#8B91A7]">
                    {char.name.charAt(0)}
                  </div>
                )}
              </div>

              {/* Info */}
              <h3 className="text-center font-semibold text-[#E8E9EB] mb-1 truncate">{char.name}</h3>
              {char.alias && <p className="text-center text-xs text-[#5A6078] mb-2 truncate">"{char.alias}"</p>}
              
              <div className="flex items-center justify-center gap-2 mb-3">
                <span 
                  className="text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full font-medium"
                  style={{ 
                    backgroundColor: `${roleLabels[char.role]?.color}15`, 
                    color: roleLabels[char.role]?.color 
                  }}
                >
                  {roleLabels[char.role]?.label}
                </span>
                <span 
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: statusColors[char.status] }}
                  title={char.status}
                />
              </div>

              {char.house && (
                <p className="text-center text-xs text-[#5A6078] truncate">{char.house}</p>
              )}

              <div className="mt-3 pt-3 border-t border-[#1E2230] flex items-center justify-between text-xs text-[#5A6078]">
                <span>{char.age || '?'} años</span>
                <span>{char.relationships.length} relaciones</span>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
