import { useState } from 'react';
import { useStore } from '@/store';
import { motion } from 'framer-motion';
import { Plus, Search, MapPin, Heart } from 'lucide-react';
const typeLabels: Record<string, string> = {
  city: 'Ciudad', town: 'Pueblo', kingdom: 'Reino', forest: 'Bosque',
  mountain: 'Montaña', dungeon: 'Mazmorra', castle: 'Castillo', temple: 'Templo', other: 'Otro',
};

interface Props { worldId: string; }

export function PlacesSection({ worldId }: Props) {
  const places = useStore((s) => s.getPlacesByWorld(worldId));
  const addPlace = useStore((s) => s.addPlace);
  const toggleFav = useStore((s) => s.toggleFavoritePlace);
  const [search, setSearch] = useState('');

  const filtered = places.filter((p) => !search || p.name.toLowerCase().includes(search.toLowerCase()));

  const handleAdd = () => {
    const name = prompt('Nombre del lugar:');
    if (!name) return;
    addPlace({ worldId, name, type: 'other', description: '', mapUrl: '', customs: '', symbols: '', isFavorite: false, isDeleted: false, tags: [] });
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="flex-1 relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#5A6078]" />
          <input type="text" placeholder="Buscar lugares..." value={search} onChange={(e) => setSearch(e.target.value)} className="story-input w-full pl-10" />
        </div>
        <button onClick={handleAdd} className="story-btn-primary text-sm"><Plus size={16} /> Agregar</button>
      </div>
      {filtered.length === 0 ? (
        <div className="text-center py-16">
          <MapPin size={48} className="text-[#2A3045] mx-auto mb-4" />
          <p className="text-[#5A6078] mb-4">No hay lugares</p>
          <button onClick={handleAdd} className="story-btn-primary text-sm"><Plus size={16} /> Crear Lugar</button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((place, i) => (
            <motion.div key={place.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }} className="story-card p-5 group relative">
              <button onClick={() => toggleFav(place.id)} className="absolute top-3 right-3 p-1.5 rounded-lg hover:bg-[#1E2230] transition-all">
                <Heart size={14} className={place.isFavorite ? 'text-[#D61E2B] fill-[#D61E2B]' : 'text-[#5A6078]'} />
              </button>
              {place.mapUrl && (
                <div className="aspect-video rounded-lg overflow-hidden mb-3 bg-[#0B0D10]">
                  <img src={place.mapUrl} alt={place.name} className="w-full h-full object-cover" />
                </div>
              )}
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[10px] uppercase tracking-wider text-[#5A6078] bg-[#1E2230] px-2 py-0.5 rounded-full">{typeLabels[place.type]}</span>
              </div>
              <h3 className="font-semibold text-[#E8E9EB] mb-1">{place.name}</h3>
              {place.description && <p className="text-xs text-[#8B91A7] line-clamp-3">{place.description}</p>}
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
