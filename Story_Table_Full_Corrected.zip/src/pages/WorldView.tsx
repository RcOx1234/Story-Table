import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useStore } from '@/store';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Users, MapPin, FileText, Route, Globe,
  Heart, Plus, ArrowLeft, Shield, Box,
  Building2, Lightbulb, Clock
} from 'lucide-react';
import { CharactersSection } from '@/sections/CharactersSection';
import { ScenesSection } from '@/sections/ScenesSection';
import { PlacesSection } from '@/sections/PlacesSection';
import { TimelinesSection } from '@/sections/TimelinesSection';
import { PlotsSection } from '@/sections/PlotsSection';
import { OrganizationsSection } from '@/sections/OrganizationsSection';
import { ComponentsSection } from '@/sections/ComponentsSection';
import { WorldIdeasSection } from '@/sections/WorldIdeasSection';
import type { SectionType } from '@/types';

const tabs: { id: SectionType; label: string; icon: typeof Users }[] = [
  { id: 'characters', label: 'Personajes', icon: Users },
  { id: 'scenes', label: 'Escenas', icon: FileText },
  { id: 'places', label: 'Lugares', icon: MapPin },
  { id: 'plots', label: 'Tramas', icon: Route },
  { id: 'maps', label: 'Mapas', icon: Globe },
  { id: 'components', label: 'Componentes', icon: Box },
  { id: 'organizations', label: 'Organizaciones', icon: Building2 },
  { id: 'ideas', label: 'Ideas', icon: Lightbulb },
  { id: 'timelines', label: 'Timeline', icon: Clock },
];

export function WorldView() {
  const { worldId } = useParams<{ worldId: string }>();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<SectionType>('characters');
  const world = useStore((s) => s.worlds.find((w) => w.id === worldId));
  const toggleFavoriteWorld = useStore((s) => s.toggleFavoriteWorld);

  if (!world) {
    return (
      <div className="flex items-center justify-center h-[60vh]">
        <div className="text-center">
          <Globe size={48} className="text-[#2A3045] mx-auto mb-4" />
          <h2 className="text-xl text-[#E8E9EB] mb-2">Mundo no encontrado</h2>
          <button onClick={() => navigate('/')} className="story-btn-primary text-sm">
            Volver al Dashboard
          </button>
        </div>
      </div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      {/* World Header */}
      <div className="relative mb-6">
        {/* Banner */}
        <div className="relative h-48 rounded-2xl overflow-hidden mb-4">
          {world.imageUrl ? (
            <img src={world.imageUrl} alt={world.name} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-[#1E2230] to-[#2A3045]" />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-[#0B0D10] via-[#0B0D10]/40 to-transparent" />
          
          {/* Back button */}
          <button 
            onClick={() => navigate('/')}
            className="absolute top-4 left-4 p-2 rounded-lg bg-black/40 backdrop-blur-sm text-white hover:bg-black/60 transition-all"
          >
            <ArrowLeft size={18} />
          </button>

          {/* World info overlay */}
          <div className="absolute bottom-0 left-0 right-0 p-6">
            <div className="flex items-end justify-between">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <h1 className="text-2xl font-bold text-[#E8E9EB]" style={{ fontFamily: 'Montserrat' }}>
                    {world.name}
                  </h1>
                  {world.protected && <Shield size={16} className="text-[#EAB308]" />}
                </div>
                <p className="text-sm text-[#8B91A7] max-w-2xl line-clamp-2">{world.description}</p>
                <div className="flex gap-2 mt-3">
                  {world.tags.map((tag) => (
                    <span key={tag} className="text-xs uppercase tracking-wider text-[#8B91A7] bg-black/30 px-2.5 py-1 rounded-full">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => toggleFavoriteWorld(world.id)}
                  className="p-2.5 rounded-xl bg-black/40 backdrop-blur-sm hover:bg-[#D61E2B]/80 transition-all"
                >
                  <Heart size={18} className={world.isFavorite ? 'text-[#D61E2B] fill-[#D61E2B]' : 'text-white'} />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 overflow-x-auto pb-2 scrollbar-thin border-b border-[#1E2230]">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`story-tab whitespace-nowrap flex items-center gap-2 ${activeTab === tab.id ? 'active' : ''}`}
            >
              <tab.icon size={14} />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tab Content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.2 }}
        >
          {activeTab === 'characters' && <CharactersSection worldId={world.id} />}
          {activeTab === 'scenes' && <ScenesSection worldId={world.id} />}
          {activeTab === 'places' && <PlacesSection worldId={world.id} />}
          {activeTab === 'timelines' && <TimelinesSection worldId={world.id} />}
          {activeTab === 'plots' && <PlotsSection worldId={world.id} />}
          {activeTab === 'organizations' && <OrganizationsSection worldId={world.id} />}
          {activeTab === 'components' && <ComponentsSection worldId={world.id} />}
          {activeTab === 'ideas' && <WorldIdeasSection worldId={world.id} />}
          {activeTab === 'maps' && (
            <div className="text-center py-16">
              <Globe size={48} className="text-[#2A3045] mx-auto mb-4" />
              <h3 className="text-lg text-[#E8E9EB] mb-2">Mapas del Mundo</h3>
              <p className="text-sm text-[#5A6078] mb-4">Visualiza los mapas interactivos de este mundo</p>
              <button 
                onClick={() => navigate(`/world/${world.id}/map/${useStore.getState().maps.find(m => m.worldId === world.id)?.id || 'new'}`)}
                className="story-btn-primary text-sm"
              >
                <Plus size={16} /> Ver Mapas
              </button>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </motion.div>
  );
}
