import { useNavigate } from 'react-router-dom';
import { useStore } from '@/store';
import { motion } from 'framer-motion';
import { 
  Globe, Users, FileText, Lightbulb, Heart, Plus, MoreVertical,
  Clock, ArrowRight
} from 'lucide-react';

export function Dashboard() {
  const navigate = useNavigate();
  const worlds = useStore((s) => s.worlds);
  const characters = useStore((s) => s.characters.filter((c) => !c.isDeleted));
  const scenes = useStore((s) => s.scenes.filter((s) => !s.isDeleted));
  const ideas = useStore((s) => s.ideas.filter((i) => !i.isDeleted && !i.worldId));
  const toggleFavoriteWorld = useStore((s) => s.toggleFavoriteWorld);
  const addWorld = useStore((s) => s.addWorld);

  const stats = [
    { label: 'Mundos Activos', value: worlds.length, icon: Globe, color: '#D61E2B' },
    { label: 'Personajes', value: characters.length, icon: Users, color: '#3B82F6' },
    { label: 'Escenas', value: scenes.length, icon: FileText, color: '#22C55E' },
    { label: 'Ideas Libres', value: ideas.length, icon: Lightbulb, color: '#EAB308' },
  ];

  const recentIdeas = useStore((s) => s.ideas.filter((i) => !i.isDeleted && !i.worldId).slice(0, 5));
  const favCharacters = useStore((s) => s.characters.filter((c) => c.isFavorite && !c.isDeleted).slice(0, 6));

  const handleCreateWorld = () => {
    const name = prompt('Nombre del nuevo mundo:');
    if (!name) return;
    const description = prompt('Descripción (opcional):') || '';
    addWorld({
      name,
      description,
      imageUrl: '',
      tags: [],
      protected: false,
      isFavorite: false,
      isPinned: false,
    });
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 8 }} 
      animate={{ opacity: 1, y: 0 }} 
      transition={{ duration: 0.3 }}
      className="space-y-8"
    >
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <div key={stat.label} className="story-card p-5 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${stat.color}15` }}>
              <stat.icon size={22} style={{ color: stat.color }} />
            </div>
            <div>
              <p className="text-2xl font-bold text-[#E8E9EB]">{stat.value}</p>
              <p className="text-xs text-[#5A6078] uppercase tracking-wider">{stat.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Ideas Widget */}
      {recentIdeas.length > 0 && (
        <div className="story-card p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Lightbulb size={16} className="text-[#EAB308]" />
              <h3 className="font-semibold text-[#E8E9EB]">Ideas Sin Organizar</h3>
              <span className="text-xs bg-[#EAB308]/10 text-[#EAB308] px-2 py-0.5 rounded-full">{ideas.length}</span>
            </div>
            <button 
              onClick={() => navigate('/ideas')}
              className="text-xs text-[#8B91A7] hover:text-[#D61E2B] flex items-center gap-1 transition-colors"
            >
              Ver todas <ArrowRight size={12} />
            </button>
          </div>
          <div className="space-y-2">
            {recentIdeas.map((idea) => (
              <div 
                key={idea.id} 
                onClick={() => navigate('/ideas')}
                className="flex items-center gap-3 p-3 rounded-lg bg-[#0B0D10]/50 hover:bg-[#1E2230] transition-all cursor-pointer group"
              >
                <p className="flex-1 text-sm text-[#E8E9EB] truncate">{idea.description}</p>
                <span className="text-xs text-[#5A6078] px-2 py-0.5 rounded-full bg-[#1E2230]">{idea.type}</span>
                <span className="text-xs text-[#5A6078]">
                  {new Date(idea.createdAt).toLocaleDateString()}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Worlds Grid */}
      <div>
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-xl font-semibold text-[#E8E9EB]" style={{ fontFamily: 'Montserrat' }}>Mis Mundos</h2>
          <button onClick={handleCreateWorld} className="story-btn-primary text-sm">
            <Plus size={16} /> Nuevo Mundo
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {worlds.map((world, i) => (
            <motion.div
              key={world.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: i * 0.1 }}
              className="story-card overflow-hidden cursor-pointer group"
              onClick={() => navigate(`/world/${world.id}`)}
            >
              {/* Image */}
              <div className="relative aspect-video overflow-hidden">
                {world.imageUrl ? (
                  <img 
                    src={world.imageUrl} 
                    alt={world.name} 
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-[#1E2230] to-[#2A3045] flex items-center justify-center">
                    <Globe size={48} className="text-[#3A4460]" />
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-[#151820] via-transparent to-transparent" />
                
                {/* Overlay actions */}
                <div className="absolute top-3 right-3 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={(e) => { e.stopPropagation(); toggleFavoriteWorld(world.id); }}
                    className="p-2 rounded-lg bg-black/40 backdrop-blur-sm hover:bg-[#D61E2B]/80 transition-all"
                  >
                    <Heart size={14} className={world.isFavorite ? 'text-[#D61E2B] fill-[#D61E2B]' : 'text-white'} />
                  </button>
                  <button
                    onClick={(e) => e.stopPropagation()}
                    className="p-2 rounded-lg bg-black/40 backdrop-blur-sm hover:bg-[#1E2230]/80 transition-all"
                  >
                    <MoreVertical size={14} className="text-white" />
                  </button>
                </div>

                {/* Title overlay */}
                <div className="absolute bottom-0 left-0 right-0 p-4">
                  <h3 className="font-semibold text-[#E8E9EB] text-lg mb-1" style={{ fontFamily: 'Montserrat' }}>
                    {world.name}
                  </h3>
                  <div className="flex gap-1.5 flex-wrap">
                    {world.tags.slice(0, 3).map((tag) => (
                      <span key={tag} className="text-[10px] uppercase tracking-wider text-[#8B91A7] bg-black/30 px-2 py-0.5 rounded-full">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Stats bar */}
              <div className="px-4 py-3 flex items-center gap-4 border-t border-[#1E2230]">
                <div className="flex items-center gap-1.5 text-xs text-[#5A6078]">
                  <Users size={12} />
                  <span>{characters.filter((c) => c.worldId === world.id).length}</span>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-[#5A6078]">
                  <FileText size={12} />
                  <span>{scenes.filter((s) => s.worldId === world.id).length}</span>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-[#5A6078]">
                  <Clock size={12} />
                  <span>{new Date(world.updatedAt).toLocaleDateString()}</span>
                </div>
              </div>
            </motion.div>
          ))}

          {/* Create new card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: worlds.length * 0.1 }}
            onClick={handleCreateWorld}
            className="story-card border-dashed border-[#3A4460] hover:border-[#D61E2B] flex flex-col items-center justify-center aspect-[16/10] cursor-pointer transition-all min-h-[200px]"
          >
            <div className="w-14 h-14 rounded-full bg-[#1E2230] flex items-center justify-center mb-3 group-hover:bg-[#D61E2B]/10 transition-all">
              <Plus size={24} className="text-[#5A6078]" />
            </div>
            <p className="text-sm text-[#5A6078]">Crear Nuevo Mundo</p>
          </motion.div>
        </div>
      </div>

      {/* Favorite Characters */}
      {favCharacters.length > 0 && (
        <div>
          <h2 className="text-xl font-semibold text-[#E8E9EB] mb-5" style={{ fontFamily: 'Montserrat' }}>Personajes Favoritos</h2>
          <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-thin">
            {favCharacters.map((char) => (
              <div 
                key={char.id}
                onClick={() => navigate(`/world/${char.worldId}/character/${char.id}`)}
                className="flex-shrink-0 w-36 story-card p-4 cursor-pointer hover:border-[#D61E2B] transition-all group"
              >
                <div className="w-14 h-14 rounded-full bg-[#1E2230] mx-auto mb-3 overflow-hidden">
                  {char.images[0] ? (
                    <img src={char.images[0]} alt={char.name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-lg font-semibold text-[#8B91A7]">
                      {char.name.charAt(0)}
                    </div>
                  )}
                </div>
                <p className="text-sm font-medium text-[#E8E9EB] text-center truncate">{char.name}</p>
                <p className="text-xs text-[#5A6078] text-center capitalize">{char.role}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </motion.div>
  );
}
