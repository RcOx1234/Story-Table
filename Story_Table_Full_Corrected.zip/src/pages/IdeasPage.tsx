import { useState } from 'react';
import { useStore } from '@/store';
import { motion } from 'framer-motion';
import { Plus, Lightbulb, Heart, Tag, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const typeLabels: Record<string, { label: string; color: string }> = {
  scene: { label: 'Escena', color: '#22C55E' },
  character: { label: 'Personaje', color: '#3B82F6' },
  plot: { label: 'Trama', color: '#D61E2B' },
  world: { label: 'Mundo', color: '#8B5CF6' },
  dialogue: { label: 'Diálogo', color: '#EAB308' },
  lore: { label: 'Lore', color: '#EC4899' },
  other: { label: 'Otro', color: '#5A6078' },
};

export function IdeasPage() {
  const navigate = useNavigate();
  const ideas = useStore((s) => s.ideas.filter((i) => !i.isDeleted));
  const addIdea = useStore((s) => s.addIdea);
  const toggleFav = useStore((s) => s.toggleFavoriteIdea);
  const deleteIdea = useStore((s) => s.deleteIdea);
  const worlds = useStore((s) => s.worlds);
  const [filter, setFilter] = useState('');

  const filtered = ideas.filter((i) => !filter || i.type === filter);

  const handleAdd = () => {
    const desc = prompt('Describe tu idea:');
    if (!desc) return;
    addIdea({ worldId: null, description: desc, type: 'scene', references: [], isFavorite: false, isDeleted: false, tags: [] });
  };

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="max-w-4xl mx-auto">
      <div className="flex items-center gap-4 mb-6">
        <button onClick={() => navigate('/')} className="p-2 rounded-lg hover:bg-[#1E2230] transition-all">
          <ArrowLeft size={20} className="text-[#8B91A7]" />
        </button>
        <div>
          <h1 className="text-2xl font-bold text-[#E8E9EB]" style={{ fontFamily: 'Montserrat' }}>Bandeja de Ideas</h1>
          <p className="text-sm text-[#5A6078]">{ideas.length} ideas capturadas</p>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="flex gap-2 flex-wrap">
          <button onClick={() => setFilter('')} className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${!filter ? 'bg-[#D61E2B] text-white' : 'bg-[#1E2230] text-[#8B91A7]'}`}>Todas</button>
          {Object.entries(typeLabels).map(([key, { label }]) => (
            <button key={key} onClick={() => setFilter(key)} className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${filter === key ? 'bg-[#D61E2B] text-white' : 'bg-[#1E2230] text-[#8B91A7]'}`}>{label}</button>
          ))}
        </div>
        <button onClick={handleAdd} className="story-btn-primary text-sm ml-auto"><Plus size={16} /> Nueva Idea</button>
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-16">
          <Lightbulb size={48} className="text-[#2A3045] mx-auto mb-4" />
          <p className="text-[#5A6078] mb-4">Tu bandeja de ideas está vacía</p>
          <button onClick={handleAdd} className="story-btn-primary text-sm"><Plus size={16} /> Capturar Primera Idea</button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-3">
          {filtered.map((idea, i) => {
            const world = worlds.find((w) => w.id === idea.worldId);
            return (
              <motion.div key={idea.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }} className="story-card p-4 flex items-start gap-4 group">
                <button onClick={() => toggleFav(idea.id)} className="p-1.5 rounded-lg hover:bg-[#1E2230] transition-all flex-shrink-0">
                  <Heart size={14} className={idea.isFavorite ? 'text-[#D61E2B] fill-[#D61E2B]' : 'text-[#5A6078]'} />
                </button>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-[#E8E9EB] mb-2">{idea.description}</p>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full font-medium" style={{ backgroundColor: `${typeLabels[idea.type]?.color}15`, color: typeLabels[idea.type]?.color }}>
                      {typeLabels[idea.type]?.label}
                    </span>
                    {world && <span className="text-[10px] text-[#5A6078] flex items-center gap-1"><Tag size={8} /> {world.name}</span>}
                    <span className="text-[10px] text-[#5A6078]">{new Date(idea.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>
                <button onClick={() => deleteIdea(idea.id)} className="p-1.5 rounded-lg hover:bg-[#D61E2B]/10 text-[#5A6078] hover:text-[#D61E2B] transition-all opacity-0 group-hover:opacity-100">
                  <Tag size={14} />
                </button>
              </motion.div>
            );
          })}
        </div>
      )}
    </motion.div>
  );
}
