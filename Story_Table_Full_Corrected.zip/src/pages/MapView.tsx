import { useParams, useNavigate } from 'react-router-dom';
import { useStore } from '@/store';
import { motion } from 'framer-motion';
import { ArrowLeft, MapPin, ZoomIn, ZoomOut, Maximize } from 'lucide-react';
import { useState, useRef } from 'react';

export function MapView() {
  const { worldId, mapId } = useParams<{ worldId: string; mapId: string }>();
  const navigate = useNavigate();
  const mapData = useStore((s) => s.maps.find((m) => m.id === mapId));
  const [scale, setScale] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [dragging, setDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);

  if (!mapData) {
    return (
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <button onClick={() => navigate(`/world/${worldId}`)} className="p-2 rounded-lg hover:bg-[#1E2230] transition-all">
            <ArrowLeft size={20} className="text-[#8B91A7]" />
          </button>
          <h1 className="text-2xl font-bold text-[#E8E9EB]" style={{ fontFamily: 'Montserrat' }}>Mapa</h1>
        </div>
        <div className="story-card p-12 text-center">
          <MapPin size={48} className="text-[#2A3045] mx-auto mb-4" />
          <p className="text-[#5A6078]">Mapa no encontrado</p>
        </div>
      </motion.div>
    );
  }

  const handleMouseDown = (e: React.MouseEvent) => {
    setDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!dragging) return;
    setPan({ x: e.clientX - dragStart.x, y: e.clientY - dragStart.y });
  };

  const handleMouseUp = () => setDragging(false);

  const [selectedMarker, setSelectedMarker] = useState<string | null>(null);
  const activeMarker = mapData.markers.find((m) => m.id === selectedMarker);

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="h-[calc(100vh-120px)] flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between mb-4 flex-shrink-0">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(`/world/${worldId}`)} className="p-2 rounded-lg hover:bg-[#1E2230] transition-all">
            <ArrowLeft size={20} className="text-[#8B91A7]" />
          </button>
          <h1 className="text-xl font-bold text-[#E8E9EB]" style={{ fontFamily: 'Montserrat' }}>{mapData.name}</h1>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setScale((s) => Math.min(s + 0.2, 3))} className="p-2 rounded-lg bg-[#1E2230] hover:bg-[#252A3C] transition-all">
            <ZoomIn size={16} className="text-[#E8E9EB]" />
          </button>
          <button onClick={() => setScale((s) => Math.max(s - 0.2, 0.5))} className="p-2 rounded-lg bg-[#1E2230] hover:bg-[#252A3C] transition-all">
            <ZoomOut size={16} className="text-[#E8E9EB]" />
          </button>
          <button onClick={() => { setScale(1); setPan({ x: 0, y: 0 }); }} className="p-2 rounded-lg bg-[#1E2230] hover:bg-[#252A3C] transition-all">
            <Maximize size={16} className="text-[#E8E9EB]" />
          </button>
        </div>
      </div>

      {/* Map Container */}
      <div 
        ref={containerRef}
        className="flex-1 story-card overflow-hidden relative cursor-grab active:cursor-grabbing"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        <div 
          className="absolute inset-0 flex items-center justify-center"
          style={{ transform: `translate(${pan.x}px, ${pan.y}px) scale(${scale})`, transition: dragging ? 'none' : 'transform 0.2s' }}
        >
          <img 
            src={mapData.imageUrl} 
            alt={mapData.name} 
            className="max-w-full max-h-full object-contain select-none pointer-events-none"
            draggable={false}
          />
          
          {/* Markers */}
          {mapData.markers.map((marker) => (
            <button
              key={marker.id}
              onClick={(e) => { e.stopPropagation(); setSelectedMarker(selectedMarker === marker.id ? null : marker.id); }}
              className="absolute transform -translate-x-1/2 -translate-y-1/2 group"
              style={{ left: `${marker.x}%`, top: `${marker.y}%` }}
            >
              <div className={`w-6 h-6 rounded-full flex items-center justify-center transition-all ${
                selectedMarker === marker.id ? 'bg-[#D61E2B] scale-125' : 'bg-[#D61E2B]/80 hover:scale-110'
              }`}>
                <MapPin size={12} className="text-white" />
              </div>
              <div className="absolute top-7 left-1/2 -translate-x-1/2 whitespace-nowrap bg-[#151820] px-2 py-0.5 rounded text-[10px] text-[#E8E9EB] opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none border border-[#2A3045]">
                {marker.placeName}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Marker Info */}
      {activeMarker && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-4 story-card p-4 flex-shrink-0"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-[#D61E2B] flex items-center justify-center">
              <MapPin size={14} className="text-white" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-[#E8E9EB]">{activeMarker.placeName}</p>
              <p className="text-xs text-[#8B91A7]">{activeMarker.note}</p>
            </div>
            <p className="text-xs text-[#5A6078] font-mono">({activeMarker.x}%, {activeMarker.y}%)</p>
          </div>
        </motion.div>
      )}
    </motion.div>
  );
}
