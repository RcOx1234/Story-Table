import { useNavigate } from 'react-router-dom';
import { useStore } from '@/store';
import { motion } from 'framer-motion';
import { Trash2, RotateCcw, AlertTriangle, ArrowLeft, Users, FileText, MapPin, Globe } from 'lucide-react';
import { toast } from 'sonner';

export function TrashPage() {
  const navigate = useNavigate();
  const trash = useStore((s) => s.getTrashItems());
  const restoreCharacter = useStore((s) => s.restoreCharacter);
  const restoreScene = useStore((s) => s.restoreScene);
  const restorePlace = useStore((s) => s.restorePlace);
  const restorePlot = useStore((s) => s.restorePlot);
  const restoreComponent = useStore((s) => s.restoreComponent);
  const restoreOrganization = useStore((s) => s.restoreOrganization);
  const restoreIdea = useStore((s) => s.restoreIdea);
  const emptyTrash = useStore((s) => s.emptyTrash);

  const allItems = [
    ...trash.characters.map((c) => ({ type: 'character' as const, data: c, icon: Users, color: '#22C55E', restore: () => restoreCharacter(c.id) })),
    ...trash.scenes.map((s) => ({ type: 'scene' as const, data: s, icon: FileText, color: '#EAB308', restore: () => restoreScene(s.id) })),
    ...trash.places.map((p) => ({ type: 'place' as const, data: p, icon: MapPin, color: '#8B5CF6', restore: () => restorePlace(p.id) })),
    ...trash.plots.map((p) => ({ type: 'plot' as const, data: p, icon: Globe, color: '#3B82F6', restore: () => restorePlot(p.id) })),
    ...trash.components.map((c) => ({ type: 'component' as const, data: c, icon: Globe, color: '#EC4899', restore: () => restoreComponent(c.id) })),
    ...trash.organizations.map((o) => ({ type: 'organization' as const, data: o, icon: Globe, color: '#F97316', restore: () => restoreOrganization(o.id) })),
    ...trash.ideas.map((i) => ({ type: 'idea' as const, data: i, icon: Globe, color: '#D61E2B', restore: () => restoreIdea(i.id) })),
  ];

  const handleEmpty = () => {
    if (confirm('¿Eliminar permanentemente todos los elementos?')) {
      emptyTrash();
      toast.success('Papelera vaciada');
    }
  };

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="max-w-4xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate('/')} className="p-2 rounded-lg hover:bg-[#1E2230] transition-all">
            <ArrowLeft size={20} className="text-[#8B91A7]" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-[#E8E9EB]" style={{ fontFamily: 'Montserrat' }}>Papelera</h1>
            <p className="text-sm text-[#5A6078]">{allItems.length} elementos eliminados</p>
          </div>
        </div>
        {allItems.length > 0 && (
          <button onClick={handleEmpty} className="story-btn-secondary text-sm text-[#D61E2B] border-[#D61E2B]/30 hover:bg-[#D61E2B]/10">
            <AlertTriangle size={14} /> Vaciar Papelera
          </button>
        )}
      </div>

      {allItems.length === 0 ? (
        <div className="text-center py-16">
          <Trash2 size={48} className="text-[#2A3045] mx-auto mb-4" />
          <p className="text-[#5A6078]">La papelera está vacía</p>
        </div>
      ) : (
        <div className="space-y-2">
          {allItems.map((item, i) => (
            <motion.div
              key={`${item.type}-${item.data.id}`}
              initial={{ opacity: 0, x: -12 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.03 }}
              className="story-card p-4 flex items-center gap-4"
            >
              <div className="w-10 h-10 rounded-lg bg-[#D61E2B]/10 flex items-center justify-center flex-shrink-0">
                <Trash2 size={18} className="text-[#D61E2B]" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-[#E8E9EB] truncate">{(item.data as any).name || (item.data as any).title || (item.data as any).description?.slice(0, 50)}</p>
                <p className="text-xs text-[#5A6078] capitalize">{item.type} · Eliminado {new Date((item.data as any).deletedAt).toLocaleDateString()}</p>
              </div>
              <button
                onClick={() => { item.restore(); toast.success(`${item.type} restaurado`); }}
                className="p-2 rounded-lg hover:bg-[#22C55E]/10 text-[#5A6078] hover:text-[#22C55E] transition-all"
              >
                <RotateCcw size={16} />
              </button>
            </motion.div>
          ))}
        </div>
      )}
    </motion.div>
  );
}
