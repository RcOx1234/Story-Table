import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '@/store';
import { motion } from 'framer-motion';
import { BookOpen, Feather, Eye, EyeOff } from 'lucide-react';
import { toast } from 'sonner';

export function LoginPage() {
  const login = useStore((s) => s.login);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [isRegister, setIsRegister] = useState(false);
  const [name, setName] = useState('');

  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error('Completa todos los campos');
      return;
    }
    login({
      id: crypto.randomUUID(),
      email,
      displayName: name || email.split('@')[0],
      photoURL: '',
      isAuthenticated: true,
    });
    toast.success(isRegister ? 'Cuenta creada' : 'Bienvenido');

    // Después de iniciar sesión, redirigimos al usuario a la página principal.
    // Esto evita que se quede en la pantalla de acceso y asegura que la app se renderice correctamente.
    navigate('/', { replace: true });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0B0D10] relative overflow-hidden">
      {/* Ambient background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#D61E2B]/5 rounded-full blur-[128px]" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#3B82F6]/5 rounded-full blur-[128px]" />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative z-10 w-full max-w-md px-6"
      >
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-[#D61E2B] flex items-center justify-center mx-auto mb-4 shadow-lg shadow-[#D61E2B]/20">
            <Feather size={28} className="text-white" />
          </div>
          <h1 className="text-3xl font-bold text-[#E8E9EB] mb-2" style={{ fontFamily: 'Montserrat' }}>Story Table</h1>
          <p className="text-sm text-[#5A6078]">Tu mesa de trabajo creativa</p>
        </div>

        {/* Card */}
        <div className="story-card p-8">
          <h2 className="text-xl font-semibold text-[#E8E9EB] mb-6 text-center">
            {isRegister ? 'Crear Cuenta' : 'Iniciar Sesión'}
          </h2>

          <form onSubmit={handleSubmit} className="space-y-4">
            {isRegister && (
              <div>
                <label className="block text-xs font-mono uppercase tracking-wider text-[#5A6078] mb-1.5">Nombre</label>
                <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Tu nombre" className="story-input w-full" />
              </div>
            )}

            <div>
              <label className="block text-xs font-mono uppercase tracking-wider text-[#5A6078] mb-1.5">Email</label>
              <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="tu@email.com" className="story-input w-full" required />
            </div>

            <div>
              <label className="block text-xs font-mono uppercase tracking-wider text-[#5A6078] mb-1.5">Contraseña</label>
              <div className="relative">
                <input type={showPass ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••" className="story-input w-full pr-10" required />
                <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#5A6078] hover:text-[#E8E9EB]">
                  {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <button type="submit" className="story-btn-primary w-full justify-center mt-2">
              <BookOpen size={16} />
              {isRegister ? 'Crear Cuenta' : 'Entrar'}
            </button>
          </form>

          <div className="mt-6 text-center">
            <button onClick={() => setIsRegister(!isRegister)} className="text-sm text-[#8B91A7] hover:text-[#D61E2B] transition-colors">
              {isRegister ? '¿Ya tienes cuenta? Inicia sesión' : '¿No tienes cuenta? Regístrate'}
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
