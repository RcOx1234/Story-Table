export interface World {
  id: string;
  name: string;
  description: string;
  imageUrl: string;
  createdAt: string;
  updatedAt: string;
  tags: string[];
  protected: boolean;
  password?: string;
  isFavorite: boolean;
  isPinned: boolean;
}

export interface Character {
  id: string;
  worldId: string;
  name: string;
  alias: string;
  role: 'protagonist' | 'antagonist' | 'secondary' | 'supporting' | 'extra';
  house: string;
  age: number;
  ageByTimeline: Record<string, number>;
  appearance: string;
  personality: string;
  backstory: string;
  goals: string;
  fears: string;
  powers: string;
  relationships: Relationship[];
  images: string[];
  quotes: string[];
  arc: string;
  status: 'alive' | 'dead' | 'missing' | 'unknown';
  isFavorite: boolean;
  isDeleted: boolean;
  deletedAt?: string;
  createdAt: string;
  updatedAt: string;
  tags: string[];
}

export interface Relationship {
  characterId: string;
  characterName: string;
  type: string;
  description: string;
}

export interface Scene {
  id: string;
  worldId: string;
  title: string;
  description: string;
  content: string;
  characters: string[];
  placeId: string;
  placeName: string;
  timelineId: string;
  timelineName: string;
  emotionalIntensity: number;
  music: string;
  dialogues: Dialogue[];
  reveals: string[];
  images: string[];
  video: string;
  audio: string;
  status: 'pending' | 'confirmed' | 'revision' | 'discarded' | 'important' | 'secret' | 'canon' | 'noncanon';
  isFavorite: boolean;
  isDeleted: boolean;
  deletedAt?: string;
  createdAt: string;
  updatedAt: string;
  tags: string[];
}

export interface Dialogue {
  characterName: string;
  text: string;
}

export interface Place {
  id: string;
  worldId: string;
  name: string;
  type: 'city' | 'town' | 'kingdom' | 'forest' | 'mountain' | 'dungeon' | 'castle' | 'temple' | 'other';
  description: string;
  mapUrl: string;
  customs: string;
  symbols: string;
  isFavorite: boolean;
  isDeleted: boolean;
  deletedAt?: string;
  createdAt: string;
  updatedAt: string;
  tags: string[];
}

export interface MapData {
  id: string;
  worldId: string;
  name: string;
  imageUrl: string;
  markers: MapMarker[];
  createdAt: string;
  updatedAt: string;
}

export interface MapMarker {
  id: string;
  x: number;
  y: number;
  placeId: string;
  placeName: string;
  note: string;
}

export interface Plot {
  id: string;
  worldId: string;
  title: string;
  synopsis: string;
  characters: string[];
  relatedPlots: string[];
  twists: string[];
  isFavorite: boolean;
  isDeleted: boolean;
  deletedAt?: string;
  createdAt: string;
  updatedAt: string;
  tags: string[];
}

export interface Component {
  id: string;
  worldId: string;
  name: string;
  description: string;
  history: string;
  target: string;
  scenes: string[];
  type: 'object' | 'letter' | 'relic' | 'weapon' | 'artifact' | 'other';
  isFavorite: boolean;
  isDeleted: boolean;
  deletedAt?: string;
  createdAt: string;
  updatedAt: string;
  tags: string[];
}

export interface Organization {
  id: string;
  worldId: string;
  name: string;
  members: string[];
  goals: string;
  symbols: string;
  hierarchy: string;
  type: 'guild' | 'house' | 'brotherhood' | 'company' | 'clan' | 'other';
  isFavorite: boolean;
  isDeleted: boolean;
  deletedAt?: string;
  createdAt: string;
  updatedAt: string;
  tags: string[];
}

export interface Idea {
  id: string;
  worldId: string | null;
  description: string;
  type: 'scene' | 'character' | 'plot' | 'world' | 'dialogue' | 'lore' | 'other';
  references: string[];
  isFavorite: boolean;
  isDeleted: boolean;
  deletedAt?: string;
  createdAt: string;
  updatedAt: string;
  tags: string[];
}

export interface Timeline {
  id: string;
  worldId: string;
  name: string;
  description: string;
  order: number;
  startDate: string;
  endDate: string;
  color: string;
  createdAt: string;
  updatedAt: string;
}

export type SectionType = 
  | 'characters' 
  | 'places' 
  | 'scenes' 
  | 'plots' 
  | 'maps' 
  | 'components' 
  | 'organizations' 
  | 'ideas' 
  | 'timelines';

export interface User {
  id: string;
  email: string;
  displayName: string;
  photoURL: string;
  isAuthenticated: boolean;
}
