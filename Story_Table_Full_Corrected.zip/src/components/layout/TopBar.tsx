import { useStore } from '@/store';
import { Search, Plus, Bell, Command } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function TopBar() {
  const setActiveModal = useStore((s) => s.setActiveModal);
  const navigate = useNavigate();
  const user = useStore((s) => s.user);

  return (
    /*
     * Cabecera actualizada: se utiliza un fondo rojo para la barra superior
     * conforme al brief, con un borde inferior ligeramente más oscuro. Se
     * elimina el desenfoque de fondo (backdrop-blur) para obtener un color
     * sólido y coherente con el resto de la aplicación.
     */
    <header className="h-16 bg-[#D61E2B] border-b border-[#B51823] flex items-center px-6 gap-4 flex-shrink-0 sticky top-0 z-40">
      {/* Search */}
      <button
        onClick={() => setActiveModal('search')}
        className="flex-1 max-w-md flex items-center gap-3 px-4 py-2 rounded-xl bg-[#1E2230] border border-[#2A3045] text-[#5A6078] hover:border-[#3A4460] transition-all text-sm"
      >
        <Search size={16} />
        <span className="flex-1 text-left">Buscar mundos, personajes, escenas...</span>
        <div className="flex items-center gap-1 text-xs text-[#5A6078]">
          <Command size={12} />
          <span>K</span>
        </div>
      </button>

      <div className="flex-1" />

      {/* Actions */}
      <div className="flex items-center gap-2">
        <button 
          onClick={() => setActiveModal('quick-capture')}
          className="story-btn-primary text-sm"
        >
          <Plus size={16} />
          <span className="hidden sm:inline">Capturar</span>
        </button>

        <button className="p-2.5 rounded-xl text-[#8B91A7] hover:text-[#E8E9EB] hover:bg-[#1E2230] transition-all relative">
          <Bell size={18} />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-[#D61E2B] rounded-full" />
        </button>

        <button 
          onClick={() => navigate('/')}
          className="w-9 h-9 rounded-full bg-[#D61E2B]/20 flex items-center justify-center text-[#D61E2B] font-semibold text-sm hover:bg-[#D61E2B]/30 transition-all"
        >
          {user?.displayName?.charAt(0) || 'U'}
        </button>
      </div>
    </header>
  );
}
