import { useState } from 'react';
import { useStore } from '@/store';
import { motion } from 'framer-motion';
import { X, Type, Mic, Image, Send } from 'lucide-react';
import { toast } from 'sonner';

export function QuickCaptureModal() {
  const activeModal = useStore((s) => s.activeModal);
  const setActiveModal = useStore((s) => s.setActiveModal);
  const addIdea = useStore((s) => s.addIdea);
  const worlds = useStore((s) => s.worlds);

  const [tab, setTab] = useState<'text' | 'audio' | 'image'>('text');
  const [text, setText] = useState('');
  const [ideaType, setIdeaType] = useState('scene');
  const [worldId, setWorldId] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);

  if (activeModal !== 'quick-capture') return null;

  const handleSave = () => {
    if (!text.trim()) {
      toast.error('Escribe algo primero');
      return;
    }
    addIdea({
      worldId,
      description: text,
      type: ideaType as any,
      references: [],
      isFavorite: false,
      isDeleted: false,
      tags: [],
    });
    toast.success('Idea guardada');
    setText('');
    setActiveModal(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={() => setActiveModal(null)}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-lg story-card overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-[#1E2230]">
          <h2 className="text-lg font-semibold text-[#E8E9EB]" style={{ fontFamily: 'Montserrat' }}>Captura Rápida</h2>
          <button onClick={() => setActiveModal(null)} className="p-1.5 rounded-lg hover:bg-[#1E2230] transition-all">
            <X size={18} className="text-[#5A6078]" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-[#1E2230]">
          <button onClick={() => setTab('text')} className={`flex-1 py-3 text-sm font-medium flex items-center justify-center gap-2 transition-all ${tab === 'text' ? 'text-[#D61E2B] border-b-2 border-[#D61E2B]' : 'text-[#5A6078]'}`}>
            <Type size={14} /> Texto
          </button>
          <button onClick={() => setTab('audio')} className={`flex-1 py-3 text-sm font-medium flex items-center justify-center gap-2 transition-all ${tab === 'audio' ? 'text-[#D61E2B] border-b-2 border-[#D61E2B]' : 'text-[#5A6078]'}`}>
            <Mic size={14} /> Audio
          </button>
          <button onClick={() => setTab('image')} className={`flex-1 py-3 text-sm font-medium flex items-center justify-center gap-2 transition-all ${tab === 'image' ? 'text-[#D61E2B] border-b-2 border-[#D61E2B]' : 'text-[#5A6078]'}`}>
            <Image size={14} /> Imagen
          </button>
        </div>

        {/* Content */}
        <div className="p-5">
          {tab === 'text' && (
            <div className="space-y-4">
              <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Escribe tu idea aquí..."
                className="story-input w-full h-32 resize-none"
                autoFocus
              />
              <div className="flex gap-3">
                <select value={ideaType} onChange={(e) => setIdeaType(e.target.value)} className="story-input text-sm">
                  <option value="scene">Escena</option>
                  <option value="character">Personaje</option>
                  <option value="plot">Trama</option>
                  <option value="dialogue">Diálogo</option>
                  <option value="lore">Lore</option>
                  <option value="other">Otro</option>
                </select>
                <select value={worldId || ''} onChange={(e) => setWorldId(e.target.value || null)} className="story-input text-sm flex-1">
                  <option value="">Bandeja de ideas</option>
                  {worlds.map((w) => (
                    <option key={w.id} value={w.id}>{w.name}</option>
                  ))}
                </select>
              </div>
              <button onClick={handleSave} className="story-btn-primary w-full justify-center">
                <Send size={14} /> Guardar Idea
              </button>
            </div>
          )}

          {tab === 'audio' && (
            <div className="text-center py-8">
              <button
                onClick={() => setIsRecording(!isRecording)}
                className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 transition-all ${
                  isRecording ? 'bg-[#D61E2B] animate-pulse' : 'bg-[#1E2230] hover:bg-[#252A3C]'
                }`}
              >
                <Mic size={28} className={isRecording ? 'text-white' : 'text-[#5A6078]'} />
              </button>
              <p className="text-sm text-[#8B91A7]">
                {isRecording ? 'Grabando...' : 'Toca para grabar'}
              </p>
              <p className="text-xs text-[#5A6078] mt-2">Función de audio simulada</p>
            </div>
          )}

          {tab === 'image' && (
            <div className="text-center py-8">
              <div className="w-full h-32 border-2 border-dashed border-[#2A3045] rounded-xl flex flex-col items-center justify-center mb-4 hover:border-[#D61E2B] transition-colors cursor-pointer">
                <Image size={32} className="text-[#5A6078] mb-2" />
                <p className="text-sm text-[#8B91A7]">Arrastra una imagen aquí</p>
                <p className="text-xs text-[#5A6078]">o haz clic para seleccionar</p>
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
