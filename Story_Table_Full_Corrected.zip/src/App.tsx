import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useEffect } from 'react';
import { useStore } from '@/store';
import { seedData } from '@/data/seed';
import { MainLayout } from '@/components/layout/MainLayout';
import { Dashboard } from '@/pages/Dashboard';
import { WorldView } from '@/pages/WorldView';
import { CharacterDetail } from '@/pages/CharacterDetail';
import { SceneDetail } from '@/pages/SceneDetail';
import { IdeasPage } from '@/pages/IdeasPage';
import { FavoritesPage } from '@/pages/FavoritesPage';
import { TrashPage } from '@/pages/TrashPage';
import { PlaceDetail } from '@/pages/PlaceDetail';
import { MapView } from '@/pages/MapView';
import { QuickCaptureModal } from '@/components/modals/QuickCaptureModal';
import { SearchModal } from '@/components/modals/SearchModal';
import { LoginPage } from '@/pages/LoginPage';
import { Toaster } from '@/components/ui/sonner';

function AppContent() {
  const user = useStore((s) => s.user);

  useEffect(() => {
    seedData(useStore);
  }, []);

  if (!user) {
    return <LoginPage />;
  }

  return (
    <>
      <MainLayout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/world/:worldId" element={<WorldView />} />
          <Route path="/world/:worldId/character/:characterId" element={<CharacterDetail />} />
          <Route path="/world/:worldId/scene/:sceneId" element={<SceneDetail />} />
          <Route path="/world/:worldId/place/:placeId" element={<PlaceDetail />} />
          <Route path="/world/:worldId/map/:mapId" element={<MapView />} />
          <Route path="/ideas" element={<IdeasPage />} />
          <Route path="/favorites" element={<FavoritesPage />} />
          <Route path="/trash" element={<TrashPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </MainLayout>
      <QuickCaptureModal />
      <SearchModal />
      <Toaster 
        position="top-right"
        toastOptions={{
          style: {
            background: '#151820',
            border: '1px solid #2A3045',
            color: '#E8E9EB',
          },
        }}
      />
    </>
  );
}

function App() {
  return (
    <BrowserRouter>
      <AppContent />
    </BrowserRouter>
  );
}

export default App;
